import SwiftUI
import AVFoundation
import Network
import CoreImage
import ImageIO
import UIKit

@main
struct BureauCameraApp: App {
    var body: some Scene { WindowGroup { CameraView() } }
}

struct CameraView: View {
    @StateObject private var camera = CameraController()
    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            VStack(spacing: 20) {
                Text("BUREAU CAMERA").font(.largeTitle.bold())
                Text(camera.status).multilineTextAlignment(.center)
                Text("Ultra grand-angle · cible 1920 × 1080 / 60 i/s")
                Text("Branchez le câble USB, lancez le récepteur PC et gardez cette app ouverte.")
                    .font(.callout).foregroundColor(.gray)
                Button("Démarrer / réessayer") { camera.start() }
                    .buttonStyle(.borderedProminent)
                Text("Prototype : le débit réel sera affiché sur le PC. Aucun son transmis.")
                    .font(.caption).foregroundColor(.gray)
            }.padding(30).foregroundColor(.white)
        }.onAppear { camera.start() }
    }
}

final class CameraController: NSObject, ObservableObject, AVCaptureVideoDataOutputSampleBufferDelegate {
    @Published var status = "Autorisation caméra…"
    private let queue = DispatchQueue(label: "bureau.camera")
    private let session = AVCaptureSession()
    private let context = CIContext(options: [.cacheIntermediates: false])
    private let colorSpace = CGColorSpaceCreateDeviceRGB()
    private var listener: NWListener?
    private var client: NWConnection?
    private var sending = false
    private var configured = false
    private var starting = false

    private func report(_ text: String) {
        DispatchQueue.main.async { self.status = text }
    }

    func start() {
        AVCaptureDevice.requestAccess(for: .video) { allowed in
            guard allowed else {
                self.report("Autorisez la caméra dans Réglages > Bureau Camera.")
                return
            }
            self.queue.async {
                guard !self.starting, !self.configured else { return }
                self.starting = true
                defer { self.starting = false }
                do {
                    try self.configure()
                    try self.listen()
                    self.configured = true
                    self.session.startRunning()
                    DispatchQueue.main.async { UIApplication.shared.isIdleTimerDisabled = true }
                    self.report("Caméra active · en attente du PC par USB")
                } catch {
                    self.report("Impossible de démarrer : \(error.localizedDescription)")
                }
            }
        }
    }

    private func configure() throws {
        guard let device = AVCaptureDevice.default(.builtInUltraWideCamera, for: .video, position: .back) else {
            throw NSError(domain: "Camera", code: 1, userInfo: [NSLocalizedDescriptionKey: "Ultra grand-angle indisponible."])
        }
        // Require the exact requested format instead of reporting an upscaled 1080p image.
        guard let format = device.formats.first(where: {
            let size = CMVideoFormatDescriptionGetDimensions($0.formatDescription)
            return size.width == 1920 && size.height == 1080 &&
                $0.videoSupportedFrameRateRanges.contains { $0.minFrameRate <= 60 && $0.maxFrameRate >= 60 }
        }) else {
            throw NSError(domain: "Camera", code: 2, userInfo: [NSLocalizedDescriptionKey: "1080p/60 indisponible sur cet objectif."])
        }
        session.beginConfiguration()
        defer { session.commitConfiguration() }
        for input in session.inputs { session.removeInput(input) }
        for output in session.outputs { session.removeOutput(output) }
        session.sessionPreset = .inputPriority
        let input = try AVCaptureDeviceInput(device: device)
        guard session.canAddInput(input) else { throw failure("Entrée caméra refusée.") }
        session.addInput(input)
        try device.lockForConfiguration()
        device.activeFormat = format
        device.activeVideoMinFrameDuration = CMTime(value: 1, timescale: 60)
        device.activeVideoMaxFrameDuration = CMTime(value: 1, timescale: 60)
        device.unlockForConfiguration()
        let output = AVCaptureVideoDataOutput()
        output.alwaysDiscardsLateVideoFrames = true
        output.videoSettings = [kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA]
        output.setSampleBufferDelegate(self, queue: queue)
        guard session.canAddOutput(output) else { throw failure("Sortie caméra refusée.") }
        session.addOutput(output)
        if let connection = output.connection(with: .video), connection.isVideoOrientationSupported {
            connection.videoOrientation = .landscapeRight
        }
    }

    private func failure(_ message: String) -> NSError {
        NSError(domain: "Camera", code: 3, userInfo: [NSLocalizedDescriptionKey: message])
    }

    private func listen() throws {
        let parameters = NWParameters.tcp
        // usbmux connects to a device-local port. Do not expose the camera on Wi-Fi.
        parameters.requiredLocalEndpoint = .hostPort(host: "127.0.0.1", port: 5555)
        let server = try NWListener(using: parameters)
        server.newConnectionHandler = { [weak self] connection in
            guard let self = self else { return }
            self.client?.cancel()
            self.client = connection
            self.sending = false
            connection.stateUpdateHandler = { [weak self, weak connection] state in
                guard let self = self, let connection = connection, self.client === connection else { return }
                switch state {
                case .ready: self.report("PC connecté · transmission USB")
                case .failed, .cancelled:
                    self.client = nil
                    self.sending = false
                    self.report("PC déconnecté · en attente")
                default: break
                }
            }
            connection.start(queue: self.queue)
        }
        server.stateUpdateHandler = { [weak self] state in
            if case .failed(let error) = state { self?.report("USB : \(error.localizedDescription)") }
        }
        server.start(queue: queue)
        listener = server
    }

    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        guard let client = client, client.state == .ready, !sending,
              let buffer = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }
        // Bounded queue: drop late frames rather than accumulate seconds of latency.
        sending = true
        let image = CIImage(cvPixelBuffer: buffer)
        guard let jpeg = context.jpegRepresentation(of: image, colorSpace: colorSpace,
            options: [kCGImageDestinationLossyCompressionQuality as CIImageRepresentationOption: 0.65]) else {
            sending = false
            return
        }
        var length = UInt32(jpeg.count).bigEndian
        var packet = withUnsafeBytes(of: &length) { Data($0) }
        packet.append(jpeg)
        client.send(content: packet, completion: .contentProcessed { [weak self, weak client] error in
            guard let self = self, self.client === client else { return }
            self.sending = false
            if error != nil { client?.cancel() }
        })
    }
}
