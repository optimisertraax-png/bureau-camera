# Bureau Camera — prototype pour iPhone 11 et Windows

Projet source expérimental. L'application iPhone n'a PAS été compilée ou testée sur un appareil ici. Aucun IPA prêt à installer n'est inclus. Le 1080p/60 est une cible de capture : l'encodage JPEG et l'USB peuvent réduire le débit. Le compteur PC affiche les images réellement reçues. Aucune limite de durée volontaire, mais pas de garantie de fonctionnement continu. Aucun paiement, abonnement ou filigrane dans ce projet.

## Obtenir l'application depuis Windows avec Sideloadly

1. Créer un dépôt GitHub **privé** et y déposer le contenu de ce dossier, en conservant `.github/workflows/build-ios.yml` et `ios/`. Ne pas déposer le dossier parent contenant vos autres projets.
2. Dans GitHub, ouvrir Actions → Construire application iPhone → Run workflow. Le travail utilise un runner macOS distant ; vérifier les quotas et tarifs GitHub de votre compte avant de l'exécuter, un runner privé n'est pas forcément gratuit.
3. Si la compilation réussit, télécharger l'artifact BureauCamera-pour-Sideloadly, extraire le ZIP et récupérer BureauCamera-unsigned.ipa. Si elle échoue, conserver le journal pour corriger le code.
4. Ouvrir cet IPA dans Sideloadly sur Windows, sélectionner votre iPhone et signer avec votre propre compte Apple. Ne jamais communiquer votre mot de passe au développeur de ce projet ou dans le chat.
5. Suivre les demandes de confiance et de mode développeur affichées par l'iPhone/Sideloadly. Avec un compte gratuit, la signature doit généralement être renouvelée après sept jours. Le mode développeur seul ne signe pas l'application.
6. Ouvrir Bureau Camera, autoriser la caméra et garder l'app au premier plan. Tenir le téléphone en paysage. Le microphone n'est pas demandé.

## Relier le PC par câble USB

Installer Node.js LTS, Python 3 et les composants Apple permettant à Windows de reconnaître l'iPhone. Si Sideloadly voit déjà l'iPhone, la partie pilote est probablement déjà présente. Déverrouiller le téléphone et accepter « Faire confiance à cet ordinateur ».

Dans un terminal, depuis le dossier `pc` :

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -m pymobiledevice3 usbmux list --usb
```

Repérer l'UDID du téléphone USB, puis lancer le tunnel en remplaçant VOTRE_UDID (sélection explicite du téléphone USB pour éviter une connexion Wi-Fi) :

```powershell
.\.venv\Scripts\python.exe -m pymobiledevice3 usbmux forward 15555 5555 --serial VOTRE_UDID
```

Dans un autre terminal du même dossier :

```powershell
node receiver.cjs
```

Ouvrir http://127.0.0.1:8765 sur le PC. Le récepteur se reconnecte automatiquement. Les serveurs caméra et PC écoutent uniquement en local. Fermer les deux terminaux et l'app iPhone pour arrêter.

## TikTok Studio via OBS

Cette version utilise **OBS Virtual Camera** pour fournir une webcam Windows. Elle n'installe pas son propre pilote de webcam.

1. Installer OBS Studio, ajouter une source **Navigateur** avec `http://127.0.0.1:8765/?clean`.
2. Régler sa largeur à 1920, hauteur à 1080, et la fréquence personnalisée à 60 si disponible. Régler aussi la vidéo OBS en 1920 × 1080 et 60 i/s.
3. Démarrer la caméra virtuelle dans OBS.
4. Dans TikTok Studio, ajouter une caméra et sélectionner **OBS Virtual Camera**. La compatibilité exacte et la cadence acceptée restent à vérifier sur votre version de TikTok Studio.
5. Choisir séparément le micro PC dans TikTok Studio.

## Limites et validation restante

- Capture uniquement ultra grand-angle arrière, format natif 1080p/60 exigé. Un message apparaît si ce format est indisponible.
- Pas d'aperçu local iPhone : l'aperçu est sur le PC.
- Transport JPEG non compressé temporellement : bien moins efficace qu'H.264. Tester 15 à 30 minutes et mesurer les images/s avant de l'utiliser en direct. Le téléphone peut chauffer, les images peuvent être perdues. Aucune promesse de 60 i/s soutenues.
- Le mode 0,5× de l'iPhone 11 a besoin de lumière ; 60 i/s n'améliore pas les performances dans le noir.
- Installation iOS, liaison USB réelle, compilation Swift et reconnaissance TikTok non testées ici. Le test PC vérifie seulement le découpage des images reçues.
- Vérification effectuée sur Windows : syntaxe JavaScript et test de trames réussis ; serveur local lancé correctement. La requête HTTP de contrôle a été bloquée par les permissions réseau de l'environnement de développement (EACCES) : aperçu navigateur non validé.
- Le serveur ne transmet pas le flux sur Internet. La compilation distante envoie le code source à GitHub, aucune vidéo.

## Sources

- https://sideloadly.io/faq.html
- https://developer.apple.com/documentation/xcode/enabling-developer-mode-on-a-device
- https://github.com/doronz88/pymobiledevice3/blob/master/pymobiledevice3/cli/usbmux.py
- https://obsproject.com/kb/virtual-camera-guide
