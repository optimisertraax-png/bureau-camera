// Only Node built-ins. Transport: 4-byte big-endian length followed by JPEG.
const http = require('node:http');
const net = require('node:net');
let latest = null, sequence = 0, received = [], connected = false;
const MAX_FRAME = 8 * 1024 * 1024;
function createParser(onFrame) {
  let buffer = Buffer.alloc(0);
  return chunk => {
    buffer = Buffer.concat([buffer, chunk]);
    while (buffer.length >= 4) {
      const length = buffer.readUInt32BE(0);
      if (length < 4 || length > MAX_FRAME) throw Error('Invalid frame length');
      if (buffer.length < length + 4) return;
      const frame = buffer.subarray(4, length + 4);
      if (frame[0] !== 255 || frame[1] !== 216 || frame[length-2] !== 255 || frame[length-1] !== 217)
        throw Error('Invalid JPEG');
      onFrame(frame);
      buffer = buffer.subarray(length + 4);
    }
  };
}
function start() {
  function connect() {
    const socket = net.connect({host:'127.0.0.1', port:15555});
    socket.setTimeout(10000);
    const parse = createParser(frame => {
      latest = frame; sequence++; received.push(Date.now());
    });
    socket.on('connect', () => { connected = true; });
    socket.on('data', data => { try { parse(data); } catch { socket.destroy(); } });
    socket.on('timeout', () => socket.destroy());
    socket.on('error', () => {});
    socket.on('close', () => {
      connected = false; latest = null; received = [];
      setTimeout(connect, 1500);
    });
  }
  const page = `<!doctype html><html lang="fr"><meta charset="utf-8">
  <title>Bureau Camera</title><style>
  body{margin:0;background:#090c14;color:white;font:18px system-ui}main{max-width:1000px;margin:auto;padding:25px}
  img{width:100%;aspect-ratio:16/9;object-fit:contain;background:black}p{color:#abb8ce}
  body.clean main{padding:0;max-width:none}body.clean h1,body.clean p{display:none}body.clean img{height:100vh}
  </style><main><h1>Bureau Camera · USB</h1><p id="state">En attente de l’iPhone…</p>
  <img src="/video" alt="Caméra en attente"><p>Dans OBS : source Navigateur → http://127.0.0.1:8765/?clean → 1920 × 1080, 60 i/s.<br>
  Démarrer la caméra virtuelle OBS, puis choisir OBS Virtual Camera dans TikTok Studio.</p></main>
  <script>if(location.search.includes('clean'))document.body.className='clean';
  setInterval(async()=>{try{let s=await(await fetch('/status')).json();document.getElementById('state').textContent=
  s.connected?'USB connecté · '+s.fps+' images/s reçues · cible 60':'En attente : ouvrir l’app iPhone et le tunnel USB';}catch{}},1000);</script>`;
  const server = http.createServer((req,res) => {
    if(req.url === '/status') {
      const now=Date.now(); received=received.filter(t=>now-t<2000);
      res.writeHead(200,{'Content-Type':'application/json','Cache-Control':'no-store'});
      return res.end(JSON.stringify({connected,fps:Math.round(received.length/2)}));
    }
    if(req.url === '/video') {
      res.writeHead(200,{'Content-Type':'multipart/x-mixed-replace; boundary=frame','Cache-Control':'no-store'});
      let last=-1, blocked=false;
      res.on('drain',()=>{blocked=false;});
      const timer=setInterval(()=>{
        if(!latest || last===sequence || blocked) return;
        last=sequence;
        const header=Buffer.from('--frame\r\nContent-Type: image/jpeg\r\nContent-Length: '+latest.length+'\r\n\r\n');
        blocked=!res.write(Buffer.concat([header,latest,Buffer.from('\r\n')]));
      }, 8);
      res.on('close',()=>clearInterval(timer));
      return;
    }
    res.writeHead(200,{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store'});
    res.end(page);
  });
  server.listen(8765,'127.0.0.1',()=>console.log('Bureau Camera : http://127.0.0.1:8765'));
  server.on('error',err=>{console.error(err.message);process.exit(1);});
  connect();
}
module.exports={createParser};
if(require.main===module) start();
