$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
if (-not (Get-Command node -ErrorAction SilentlyContinue)) { throw 'Installez Node.js LTS pour lancer le récepteur.' }
Write-Host 'Ouvrez une seconde fenêtre pour le tunnel USB (voir LISEZ-MOI).'
Write-Host 'Aperçu : http://127.0.0.1:8765'
& node (Join-Path $PSScriptRoot 'receiver.cjs')
